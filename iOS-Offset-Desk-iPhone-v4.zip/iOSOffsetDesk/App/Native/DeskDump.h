#ifndef DESK_DUMP_H
#define DESK_DUMP_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct { uint64_t decoded, unknown, input_bytes; } DeskDumpStats;
/* mode: 0 raw .bin, 1 hex .txt, 2 ARM64 .asm. 0 = success. */
int desk_dump_range(const char *input_path, const char *output_path,
                    uint64_t file_offset, uint64_t virtual_address,
                    uint64_t length, int mode, DeskDumpStats *stats);
const char *desk_dump_error(int code);
#ifdef __cplusplus
}
#endif
#endif
