(function(){
'use strict';
const E=OffsetEvidence,el=id=>document.getElementById(id);let findings=[],page=0,busy=false;
function addressNote(row){return row.sources.some(s=>s.includes('C dump'))?'VA có nhãn từ dump C; RVA/file offset là ánh xạ theo binary đang nạp, chưa xác minh cùng phiên bản.':'Địa chỉ từ metadata; chưa xác minh vai trò chống gian lận.';}
function refresh(){findings=[];
 for(let i=0;i<rows.length;i++){const row=rows[i],evidence=E.forRow(row);if(!evidence.length)continue;
 findings.push({kind:'function',name:row.name,va:row.va,rva:row.rva,fileOffset:row.fileOffset,sliceOffset:row.sliceOffset,section:model?.codeSection(row.va)?.name||'',certainty:E.certainty(evidence),addressNote:addressNote(row),evidence,rowIndex:i,dumpLine:row.dumpLine||null});}
 if(model?.stringFindings)findings.push(...model.stringFindings);
 page=0;draw();
 const stats=window.dumpImportStats,scan=model?.stringScanStats;
 el('analysisSummary').textContent=`${findings.filter(f=>f.kind==='function').length} hàm/symbol và ${findings.filter(f=>f.kind==='string').length} chuỗi có dấu hiệu. Tất cả CHƯA XÁC MINH là anticheat. Không có kết quả không đồng nghĩa không có anticheat.`+(scan?.truncated?` Chỉ giữ 2.000/${scan.total} chuỗi trùng mẫu.`:'')+(stats?` Dump C: ${stats.functions} hàm; ${stats.truncatedPreviews} bản xem trước đã rút gọn.`:'');
 el('analysisDetail').textContent='Chọn một dòng để xem bằng chứng và loại địa chỉ.';
}
function draw(){const q=el('analysisFilter').value.trim().toLowerCase(),kind=el('analysisKind').value;
 const filtered=findings.filter(f=>(!kind||f.kind===kind)&&[f.name,OffsetDesk.hex(f.va),OffsetDesk.hex(f.fileOffset),...f.evidence.map(e=>e.category+' '+e.excerpt)].join(' ').toLowerCase().includes(q));
 page=Math.min(page,Math.max(0,Math.ceil(filtered.length/50)-1));el('analysisRows').replaceChildren();
 for(const f of filtered.slice(page*50,page*50+50)){
  const tr=document.createElement('tr');for(const value of [f.kind==='function'?'Hàm/symbol':'Chuỗi dữ liệu',f.name,OffsetDesk.hex(f.va)||'—',OffsetDesk.hex(f.rva)||'—',OffsetDesk.hex(f.fileOffset)||'—',f.certainty]){const td=document.createElement('td');td.textContent=value;tr.appendChild(td);}
  tr.onclick=()=>{el('analysisDetail').textContent=[f.kind==='function'?'Ứng viên hàm/symbol':'Vị trí chuỗi dữ liệu',f.name,`VA: ${OffsetDesk.hex(f.va)||'chưa biết'} · RVA: ${OffsetDesk.hex(f.rva)||'chưa biết'} · file offset: ${OffsetDesk.hex(f.fileOffset)||'chưa biết'}`,f.addressNote,...f.evidence.map(e=>`${e.category} | ${e.where}: ${e.excerpt}`),'Cần đọc tham chiếu và luồng xử lý để xác minh. Không suy ra ABI hoặc hiệu quả thay đổi hành vi từ bảng này.'].join('\n');
   if(f.kind==='function'){const row=rows[f.rowIndex];selected=row;clearOutput();el('details').textContent=OffsetDesk.details(row,model);el('source').value=row.signature+'\n'+row.body;el('generate').disabled=busy||!model||row.rva==null||demoMode;render();}
   else {selected=null;clearOutput();el('generate').disabled=true;el('details').textContent='Đang chọn một chuỗi dữ liệu; chưa xác định hàm tham chiếu.';el('source').value='';}
  };el('analysisRows').appendChild(tr);
 }
 el('analysisPage').textContent=`${filtered.length} mục · trang ${page+1}/${Math.max(1,Math.ceil(filtered.length/50))}`;el('analysisPrev').disabled=page===0;el('analysisNext').disabled=(page+1)*50>=filtered.length;el('analysisCSV').disabled=el('analysisJSON').disabled=busy||!findings.length;
}
function payload(){return {tool:'iOS Offset Desk 4.0',sourceName,dumpName,uuid:model?.uuid||null,base:model?.base??null,notice:'Heuristic indicators only. No confirmed anti-cheat or bypass offsets. String addresses are not function addresses. C label addresses and binary version correspondence are unverified.',rules:'evidence.js v1',dumpStats:window.dumpImportStats||null,stringScanStats:model?.stringScanStats||null,findings:findings.map(({rowIndex,...f})=>f)};}
window.setAnalysisBusy=value=>{busy=!!value;draw();};
const previous=window.rebuild;window.rebuild=function(){previous();refresh();};
let timer;el('analysisFilter').oninput=()=>{clearTimeout(timer);timer=setTimeout(()=>{page=0;draw();},150);};el('analysisKind').onchange=()=>{page=0;draw();};el('analysisPrev').onclick=()=>{page--;draw();};el('analysisNext').onclick=()=>{page++;draw();};
el('analysisJSON').onclick=()=>download('security-indicators.json',JSON.stringify(payload(),(k,v)=>typeof v==='bigint'?OffsetDesk.hex(v):v,2),'application/json');
el('analysisCSV').onclick=()=>{const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';const fields=['type','name','va','rva','file_offset','status','address_note','evidence'];const lines=findings.map(f=>[f.kind,f.name,OffsetDesk.hex(f.va),OffsetDesk.hex(f.rva),OffsetDesk.hex(f.fileOffset),f.certainty,f.addressNote,f.evidence.map(e=>e.category+': '+e.excerpt).join(' | ')].map(quote).join(','));download('security-indicators.csv','\ufeff'+fields.join(',')+'\r\n'+lines.join('\r\n'),'text/csv;charset=utf-8');};
refresh();
})();
