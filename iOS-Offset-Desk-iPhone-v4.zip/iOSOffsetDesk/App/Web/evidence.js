/* Read-only indicators. An occurrence is evidence of text/API usage, never proof of anti-cheat. */
(function(root){
'use strict';
const MAX_FILE_BYTES=100*1024*1024;
const terms=[
 ['sdk','Tên SDK/bảo mật',/\b(?:AnoSDK\w*|AntiCheatExpert|anti[_ -]?cheat|anti[_ -]?tamper)\b/i],
 ['integrity','Tính toàn vẹn',/\b(?:integrity|checksum|tamper(?:ed|ing)?|code[_ -]?signature)\b/i],
 ['environment','Môi trường thiết bị',/\b(?:jailbreak|jailbroken|root[_ -]?detect(?:ion)?|emulator[_ -]?detect(?:ion)?)\b/i],
 ['debug','Kiểm tra debugger',/\b(?:anti[_ -]?debug|debugger[_ -]?detect(?:ion)?|debugger[_ -]?attached)\b/i],
 ['report','Báo cáo bảo mật',/\b(?:cheat[_ -]?report|report[_ -]?cheat|security[_ -]?report|hack[_ -]?report)\b/i]
];
const apis=[
 ['integrity','Hàm băm (API chung)',/^(?:_?CC_(?:SHA\d+|MD5)(?:_Init|_Update|_Final)?|_?memcmp)$/],
 ['environment','Liệt kê thư viện (API chung)',/^_?dyld_image_count$|^_?dyld_get_image_name$|^_dyld_image_count$|^_dyld_get_image_name$/],
 ['debug','Thông tin tiến trình/debug (API chung)',/^_?(?:ptrace|sysctl|sysctlbyname)$/],
 ['memory','Đọc bộ nhớ (API chung)',/^_?(?:mach_vm_read|mach_vm_read_overwrite|vm_read)$/]
];
function textEvidence(text,where){return terms.filter(t=>t[2].test(String(text).replace(/_/g,' '))).map(t=>({group:t[0],category:t[1],kind:'keyword',where,excerpt:String(text).slice(0,200)}));}
function callEvidence(name){return apis.filter(t=>t[2].test(name)).map(t=>({group:t[0],category:t[1],kind:'generic-api',where:'Lời gọi trong dump C',excerpt:name}));}
function unique(evidence){const seen=new Set();return evidence.filter(e=>{const k=e.group+'|'+e.kind+'|'+e.excerpt;if(seen.has(k))return false;seen.add(k);return true;}).slice(0,24);}
function forRow(row){return unique([...textEvidence(row.name.replace(/^_+/,''),'Tên hàm/symbol'),...(row.evidence||[]),...(row.calls||[]).flatMap(callEvidence)]);}
function certainty(evidence){return evidence.some(e=>e.kind==='keyword')?'Dấu hiệu từ tên/chuỗi; chưa xác minh':'API dùng chung; bằng chứng yếu';}
function stringScanner(){let start=0,run=0,head='',hits=[],total=0;
 function flush(){if(run>=5&&run<=4096){const e=textEvidence(head,'Chuỗi ASCII trong binary');if(e.length){total++;if(hits.length<2000)hits.push({fileOffset:BigInt(start),byteLength:run,text:head.slice(0,200),evidence:e});}}run=0;head='';}
 return {push(bytes,offset){for(let i=0;i<bytes.length;i++){const b=bytes[i];if(b>=32&&b<=126){if(!run)start=offset+i;run++;if(head.length<4096)head+=String.fromCharCode(b);}else if(b===0){flush();}else{run=0;head='';}}},finish(){return {hits,total,truncated:total>hits.length};}};
}
function mapString(hit,model){const off=hit.fileOffset-BigInt(model.slice),end=off+BigInt(hit.byteLength);
 const section=model.sections.find(s=>![1,12,18].includes(s.flags&255)&&off>=BigInt(s.off)&&end<=BigInt(s.off)+s.size);
 const segment=model.segments.find(s=>off>=s.off&&end<=s.off+s.size);
 const va=segment?segment.va+off-segment.off:null;
 return {...hit,kind:'string',name:hit.text,va,rva:va===null?null:va-model.base,sliceOffset:off,section:section?section.segment+','+section.name:'ngoài section đã biết',certainty:certainty(hit.evidence),addressNote:'Địa chỉ chuỗi dữ liệu, KHÔNG phải địa chỉ hàm tham chiếu.'};
}
const api={MAX_FILE_BYTES,textEvidence,callEvidence,unique,forRow,certainty,stringScanner,mapString};root.OffsetEvidence=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
