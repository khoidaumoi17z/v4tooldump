/* Offline Mach-O metadata reader. No execution, patching or network requests. */
(function(root){
'use strict';
const hex=n=>n==null?'': '0x'+BigInt(n).toString(16).toUpperCase();
function parseMachO(buffer){
 const all=new Uint8Array(buffer),av=new DataView(buffer);
 function range(off,size,limit=all.length){if(!Number.isSafeInteger(off)||!Number.isSafeInteger(size)||off<0||size<0||off+size>limit)throw Error('File bị cắt ngắn hoặc trường kích thước không hợp lệ.');}
 range(0,4);let slice=0,size=all.length;
 const magic=av.getUint32(0,false);
 if([0xcafebabe,0xcafebabf,0xbebafeca,0xbfbafeca].includes(magic)){
  const le=magic===0xbebafeca||magic===0xbfbafeca,is64=magic===0xcafebabf||magic===0xbfbafeca;
  range(0,8);const count=av.getUint32(4,le),stride=is64?32:20;range(8,count*stride);
  let chosen=null;
  for(let i=0;i<count;i++){let p=8+i*stride,cpu=av.getUint32(p,le),sub=av.getUint32(p+4,le);
   let off=is64?Number(av.getBigUint64(p+8,le)):av.getUint32(p+8,le),sz=is64?Number(av.getBigUint64(p+16,le)):av.getUint32(p+12,le);range(off,sz);
   if(cpu===0x0100000c&&(!chosen||(sub&0xffffff)!==2))chosen={off,sz};
  }
  if(!chosen)throw Error('Universal binary không có slice ARM64.');slice=chosen.off;size=chosen.sz;
 }
 range(slice,size);const data=all.subarray(slice,slice+size),v=new DataView(buffer,slice,size);
 if(size<32||v.getUint32(0,true)!==0xfeedfacf)throw Error('Chỉ hỗ trợ Mach-O 64-bit little-endian ARM64; không hỗ trợ APK/ELF/IPA trực tiếp.');
 const cpu=v.getUint32(4,true),subtype=v.getUint32(8,true);
 if(cpu!==0x0100000c)throw Error('File không phải Mach-O ARM64.');
 const ncmd=v.getUint32(16,true),cmdBytes=v.getUint32(20,true);if(ncmd>16384)throw Error('Quá nhiều load command.');range(32,cmdBytes,size);
 const text=(p,n)=>new TextDecoder().decode(data.subarray(p,p+n)).split('\0')[0];
 const segments=[],sections=[],warnings=[];let starts=null,symtab=null,uuid=null,encrypted=false,p=32;
 for(let i=0;i<ncmd;i++){
  range(p,8,32+cmdBytes);let cmd=v.getUint32(p,true),len=v.getUint32(p+4,true);
  if(len<8)throw Error('Load command sai kích thước.');range(p,len,32+cmdBytes);
  if(cmd===0x19){
   if(len<72)throw Error('Segment bị cắt ngắn.');const seg={name:text(p+8,16),va:v.getBigUint64(p+24,true),vmsize:v.getBigUint64(p+32,true),off:v.getBigUint64(p+40,true),size:v.getBigUint64(p+48,true),prot:v.getUint32(p+60,true)};
   if(seg.size>0n)range(Number(seg.off),Number(seg.size),size);segments.push(seg);
   const n=v.getUint32(p+64,true);if(72+n*80>len)throw Error('Section table sai kích thước.');
   for(let j=0;j<n;j++){let q=p+72+j*80;sections.push({index:sections.length+1,name:text(q,16),segment:text(q+16,16),va:v.getBigUint64(q+32,true),size:v.getBigUint64(q+40,true),off:v.getUint32(q+48,true),flags:v.getUint32(q+64,true)});}
  }else if(cmd===0x26){if(len<16)throw Error('FUNCTION_STARTS không hợp lệ.');starts={off:v.getUint32(p+8,true),size:v.getUint32(p+12,true)};range(starts.off,starts.size,size);}
  else if(cmd===0x2){if(len<24)throw Error('SYMTAB không hợp lệ.');symtab={off:v.getUint32(p+8,true),n:v.getUint32(p+12,true),str:v.getUint32(p+16,true),size:v.getUint32(p+20,true)};range(symtab.off,symtab.n*16,size);range(symtab.str,symtab.size,size);}
  else if(cmd===0x1b){if(len<24)throw Error('UUID không hợp lệ.');uuid=Array.from(data.subarray(p+8,p+24));}
  else if(cmd===0x21||cmd===0x2c){if(len<20)throw Error('Encryption command không hợp lệ.');encrypted ||= v.getUint32(p+16,true)!==0;}
  p+=len;
 }
 if(p!==32+cmdBytes)throw Error('Số load command không khớp sizeofcmds.');
 const baseSeg=segments.find(s=>s.name==='__TEXT'&&s.off===0n&&s.size>0n);
 if(!baseSeg)throw Error('Không xác định được image base __TEXT.');const base=baseSeg.va;
 function map(va){for(const s of segments)if(va>=s.va&&va<s.va+s.size)return {sliceOffset:s.off+va-s.va,fileOffset:BigInt(slice)+s.off+va-s.va};return null;}
 function codeSection(va){return sections.find(s=>va>=s.va&&va<s.va+s.size&&(s.name==='__text'||(s.flags&0x80000000)!==0||(s.flags&0x400)!==0)&&!['__stubs','__auth_stubs','__stub_helper'].includes(s.name));}
 const rows=new Map();
 function add(va,name,source){if(!codeSection(va)||!map(va))return;const k=va.toString();let r=rows.get(k);if(!r){if(rows.size>=100000)throw Error('Binary có quá nhiều mục hàm; dùng công cụ desktop.');r={name:name||'sub_'+va.toString(16).toUpperCase(),va,base,rva:va-base,...map(va),sources:[],body:'',signature:'',calls:[]};rows.set(k,r);}if(name)r.name=name;if(!r.sources.includes(source))r.sources.push(source);}
 if(starts){let q=starts.off,end=q+starts.size,address=base,terminated=false;
  while(q<end){let value=0n,shift=0n,b;
   do{if(q>=end||shift>63n)throw Error('ULEB128 function starts không hợp lệ.');b=data[q++];value|=BigInt(b&127)<<shift;shift+=7n;}while(b&128);
   if(value===0n){terminated=true;break;}address+=value;add(address,null,'LC_FUNCTION_STARTS');
  }
  if(starts.size&&!terminated)throw Error('Function starts thiếu ký tự kết thúc.');
 }
 if(symtab&&symtab.n>2000000)throw Error('Symbol table quá lớn cho iPhone.');
 if(symtab)for(let i=0;i<symtab.n;i++){let q=symtab.off+i*16,strx=v.getUint32(q,true),type=data[q+4],sect=data[q+5],va=v.getBigUint64(q+8,true);
  if((type&0xe0)!==0||(type&0x0e)!==0x0e||!sect||strx>=symtab.size)continue;
  const s=sections[sect-1];if(!s||va<s.va||va>=s.va+s.size)continue;
  let end=symtab.str+strx;while(end<symtab.str+symtab.size&&data[end])end++;
  const name=new TextDecoder().decode(data.subarray(symtab.str+strx,end));add(va,name,'LC_SYMTAB code symbol (có thể là nhãn)');
 }
 if(encrypted)warnings.push('cryptid != 0: vùng mã còn mã hóa; chỉ đọc metadata, không giải mã hoặc xác minh logic.');
 if((subtype&0xffffff)===2)warnings.push('ARM64e: chỉ xuất bảng địa chỉ; không sinh mã cài inline hook vì PAC cần xử lý riêng.');
 if(!rows.size)warnings.push('Không có địa chỉ từ metadata được hỗ trợ. Dùng Ghidra để nhận diện hàm; không suy đoán từ byte ngẫu nhiên.');
 warnings.push('Danh sách metadata không bảo đảm bao gồm mọi hàm; symbol có thể là nhãn, function starts không cung cấp chữ ký hay ý nghĩa.');
 return attachModel({base,slice,size,uuid,subtype,encrypted,segments,sections,rows:[...rows.values()].sort((a,b)=>a.va<b.va?-1:a.va>b.va?1:0),warnings});
}
// Separate closure keeps metadata without retaining the imported 100 MiB buffer.
function attachModel(model){
 model.map=va=>{for(const s of model.segments)if(va>=s.va&&va<s.va+s.size)return {sliceOffset:s.off+va-s.va,fileOffset:BigInt(model.slice)+s.off+va-s.va};return null;};
 model.codeSection=va=>model.sections.find(s=>va>=s.va&&va<s.va+s.size&&(s.name==='__text'||(s.flags&0x80000400)!==0)&&!['__stubs','__auth_stubs','__stub_helper'].includes(s.name));
 return model;
}
function maskCode(s){return s.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g,m=>m.replace(/[^\n]/g,' '));}
function parseDump(source){
 const clean=maskCode(source),re=/\b((?:sub_|FUN_)[0-9a-fA-F]+)\s*\([^;{}]*\)\s*\{/g,rows=[];let m;
 while((m=re.exec(clean))){let begin=re.lastIndex-1,q=begin+1,depth=1;
  for(;q<clean.length&&depth;q++){if(clean[q]==='{')depth++;else if(clean[q]==='}')depth--;}
  if(depth)continue;const va=BigInt('0x'+m[1].replace(/^(sub_|FUN_)/,''));
  let sigStart=clean.lastIndexOf('\n',m.index)+1;
  const body=source.slice(begin,q),signature=source.slice(sigStart,begin).trim();
  const calls=[...new Set([...maskCode(body).matchAll(/\b([A-Za-z_$][\w$]*)\s*\(/g)].map(x=>x[1]).filter(x=>!['if','for','while','switch','sizeof','return'].includes(x)))];
  rows.push({name:m[1],va,base:null,rva:null,fileOffset:null,sliceOffset:null,sources:['C dump: địa chỉ suy từ tên, chưa xác minh'],body,signature,calls});re.lastIndex=q;
 }
 return rows;
}
function mergeDump(model,dumpRows){
 const byVA=new Map(model.rows.map(r=>[r.va.toString(),{...r,sources:[...r.sources]}]));
 for(const d of dumpRows){let r=byVA.get(d.va.toString());
  if(r){r.body=d.body;r.signature=d.signature;r.calls=d.calls;r.evidence=d.evidence;r.dumpLine=d.dumpLine;r.bodyTruncated=d.bodyTruncated;r.callsTruncated=d.callsTruncated;r.sources.push('C dump cùng địa chỉ: chưa xác minh cùng phiên bản');}
  else{const mapping=model.map(d.va);r={...d};if(mapping&&model.codeSection(d.va)){Object.assign(r,mapping,{base:model.base,rva:d.va-model.base});r.sources.push('Ánh xạ được vào section mã; chưa xác minh điểm đầu hàm');}byVA.set(d.va.toString(),r);}
 }
 return [...byVA.values()].sort((a,b)=>a.va<b.va?-1:a.va>b.va?1:0);
}
function details(row,model){
 let result=[`Tên: ${row.name}`,`Địa chỉ từ metadata/nhãn: ${hex(row.va)}`,`RVA (__TEXT): ${hex(row.rva)||'chưa biết'}`,`File offset toàn file: ${hex(row.fileOffset)||'chưa biết'}`,`Offset trong slice: ${hex(row.sliceOffset)||'chưa biết'}`,`Nguồn: ${row.sources.join('; ')}`,`Chữ ký dump (chưa xác minh ABI): ${row.signature||'không có'}`,`Hàm được gọi trong dump (tham khảo): ${row.calls.join(', ')||'không có dữ liệu'}`];
 if(row.bodyTruncated)result.push('Thân hàm chỉ là bản xem trước đã rút gọn.');
 if(row.callsTruncated)result.push('Danh sách lời gọi chỉ giữ 256 tên đầu tiên.');
 if(row.dumpLine)result.push('Dòng mở thân hàm trong dump C: '+row.dumpLine);
 if(row.body){const returns=[...new Set([...maskCode(row.body).matchAll(/\breturn\s+([^;]+);/g)].map(m=>m[1].trim()))];result.push('Biểu thức return: '+returns.join(' | '));}
 result.push('Không kết luận chức năng chống gian lận hoặc hiệu quả tránh ban.');return result.join('\n');
}
const TYPES=['void','int32_t','uint32_t','int64_t','uint64_t','uintptr_t','float','double','void*','uint8_t*','const void*','const uint8_t*'];
function generateHook(row,model,returnType,paramText,image,normalize){
 const params=paramText.trim()?paramText.split(',').map(x=>x.trim()):[];
 if(!TYPES.includes(returnType)||params.some(x=>!TYPES.includes(x)||x==='void'))throw Error('Chỉ hỗ trợ kiểu trong danh sách; struct, C++, varargs cần viết thủ công.');
 if(params.length>16)throw Error('Quá nhiều tham số.');
 if(normalize&&!['int32_t','int64_t'].includes(returnType))throw Error('Đổi -1 thành 0 chỉ hỗ trợ int32_t/int64_t.');
 if(!model||row.rva==null||!model.codeSection(row.va)||!model.map(row.va))throw Error('Cần file Mach-O và địa chỉ được ánh xạ vào vùng mã trước khi sinh mã iOS.');
 if(model.encrypted)throw Error('File còn mã hóa: không sinh hook chưa xác minh.');
 if((model.subtype&0xffffff)===2)throw Error('ARM64e/PAC chưa được hỗ trợ bởi bộ sinh mã này.');
 if(!model.uuid)throw Error('File thiếu LC_UUID: không sinh mã cài hook tự động cho phiên bản không định danh.');
 if(!image.trim()||/["\\\n\r]/.test(image))throw Error('Nhập tên file image, không dùng đường dẫn/ký tự đặc biệt.');
 const decl=params.map((x,i)=>`${x} a${i+1}`).join(', '),args=params.map((_,i)=>'a'+(i+1)).join(', '),id='fn_'+row.va.toString(16);
 const uuid=model.uuid.map(n=>'0x'+n.toString(16).padStart(2,'0')).join(', ');
 const body=returnType==='void'?`    original_${id}(${args});`:`    ${returnType} result = original_${id}(${args});\n${normalize?'    if (result == -1) return 0;\n':''}    return result;`;
 return `// Generated by iOS Offset Desk. Signature must match the actual ARM64 ABI.\n// Function: ${row.name.replace(/[\r\n]/g,' ')} | VA ${hex(row.va)} | RVA ${hex(row.rva)}\n// File offset ${hex(row.fileOffset)} | Sources: ${row.sources.join('; ')}\n// This template does not establish anti-cheat behavior or ban prevention.\n#include <cstdint>\n#include <cstddef>\n#include <cstring>\n#include <mach-o/dyld.h>\n#include <mach-o/loader.h>\n#include "dobby.h"\n\nusing Target_${id} = ${returnType} (*)(${params.join(', ')});\nstatic Target_${id} original_${id} = nullptr;\nstatic bool installed_${id} = false;\n\nstatic ${returnType} hook_${id}(${decl}) {\n${body}\n}\n\n// Call explicitly after the correct image is loaded. No automatic constructor.\nint install_${id}() {\n    if (installed_${id}) return 0;\n    const uint8_t expected_uuid[16] = {${uuid}};\n    int found = -1;\n    for (uint32_t i = 0; i < _dyld_image_count(); ++i) {\n        const char* path = _dyld_get_image_name(i);\n        if (!path) continue;\n        const char* slash = std::strrchr(path, '/');\n        const char* basename = slash ? slash + 1 : path;\n        if (std::strcmp(basename, "${image}") != 0) continue;\n        if (found != -1) return -2; // Ambiguous image name.\n        found = static_cast<int>(i);\n    }\n    if (found < 0) return -3;\n    const auto* header = reinterpret_cast<const mach_header_64*>(_dyld_get_image_header(found));\n    if (!header || header->magic != MH_MAGIC_64 || header->cputype != 0x0100000c || (header->cpusubtype & 0x00ffffff) == 2) return -4;\n    const uint8_t* cursor = reinterpret_cast<const uint8_t*>(header) + sizeof(*header);\n    const uint8_t* end = cursor + header->sizeofcmds;\n    bool uuid_matches = false;\n    for (uint32_t j = 0; j < header->ncmds; ++j) {\n        if (end - cursor < static_cast<ptrdiff_t>(sizeof(load_command))) return -5;\n        const auto* command = reinterpret_cast<const load_command*>(cursor);\n        if (command->cmdsize < sizeof(load_command) || command->cmdsize > static_cast<size_t>(end-cursor)) return -5;\n        if (command->cmd == LC_UUID && command->cmdsize >= sizeof(uuid_command)) {\n            const auto* u = reinterpret_cast<const uuid_command*>(cursor);\n            uuid_matches = std::memcmp(u->uuid, expected_uuid, 16) == 0;\n        }\n        cursor += command->cmdsize;\n    }\n    if (!uuid_matches) return -6; // Different binary/version.\n    const intptr_t slide = _dyld_get_image_vmaddr_slide(found);\n    const uintptr_t address = static_cast<uintptr_t>(${hex(row.va)}ULL) + static_cast<uintptr_t>(slide);\n    int status = DobbyHook(reinterpret_cast<void*>(address),\n                           reinterpret_cast<void*>(hook_${id}),\n                           reinterpret_cast<void**>(&original_${id}));\n    if (status == 0) installed_${id} = true;\n    return status;\n}\n`;
}
function csv(rows){const fields=['name','va','rva','file_offset','slice_offset','source','signature'];const quote=s=>'"'+String(s).replace(/"/g,'""')+'"';return '\ufeff'+fields.join(',')+'\r\n'+rows.map(r=>[r.name,hex(r.va),hex(r.rva),hex(r.fileOffset),hex(r.sliceOffset),r.sources.join('; '),r.signature].map(quote).join(',')).join('\r\n');}
const api={hex,parseMachO,parseDump,mergeDump,details,generateHook,csv,TYPES};root.OffsetDesk=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
