const assert=require('node:assert/strict');
const E=require('../App/Web/evidence.js');
const D=require('../App/Web/dump-stream.js');
const Core=require('../App/Web/core.js');
function read(text,size=17){const p=D.create();for(let i=0;i<text.length;i+=size)p.push(text.slice(i,i+size));return p.finish();}
const source=`/* fake void sub_DEAD() { return ptrace(); } */
int64_t sub_100001000(uint8_t *p) {
 // fake integrity ptrace()
 const char *a="jailbreak detected { \\" quote";
 if (p) { sysctl(0); }
 return sub_100001080(p);
}
void sub_100001080(void *a) { puts("normal"); }
`;
for(const n of [1,2,3,7,64,65536]){const got=read(source,n);assert.equal(got.rows.length,2);assert.equal(got.rows[0].name,'sub_100001000');assert(got.rows[0].calls.includes('sysctl'));assert(!got.rows[0].calls.includes('ptrace'));assert(got.rows[0].evidence.some(e=>e.group==='environment'));assert(!got.rows[0].evidence.some(e=>e.group==='integrity'));assert.equal(got.rows[0].body,Core.parseDump(source)[0].body);}
assert.throws(()=>read('void sub_100() { puts("oops'),/kết thúc/);
assert.throws(()=>read('00000000000077E0  C0035FD6  ret\n'),/ASM/);
assert.equal(read('void sub_100() { /* integrity */ return; }').rows[0].evidence.length,0);
assert.equal(E.forRow({name:'_AnoSDKInit',calls:[]}).length,1);
const long=read('void sub_100() {'+'x++;'.repeat(15000)+'sysctl(0); puts("integrity");}',4096);assert(long.rows[0].bodyTruncated);assert(long.rows[0].evidence.some(e=>e.group==='debug'));assert(long.rows[0].evidence.some(e=>e.group==='integrity'));assert(long.rows[0].body.length<=32768);
const scan=E.stringScanner();const buf=Buffer.from('normal\0jailbreak_detect\0not terminated integrity');for(let i=0;i<buf.length;i+=3)scan.push(buf.subarray(i,i+3),i);const hits=scan.finish();assert.equal(hits.hits.length,1);assert.equal(hits.hits[0].fileOffset,7n);
const model={slice:32,base:0x1000n,segments:[{off:0n,size:100n,va:0x1000n}],sections:[{off:0,size:100n,va:0x1000n,name:'__cstring',segment:'__TEXT',flags:2}]};const mapped=E.mapString({...hits.hits[0],fileOffset:39n},model);assert.equal(mapped.va,0x1007n);assert.equal(mapped.rva,7n);assert(mapped.addressNote.includes('KHÔNG'));
// Exercise the full accepted C input size without allocating a 100 MiB string.
const start='/*',end='*/\nvoid sub_100() { puts("anti-cheat"); }';const p=D.create();p.push(start);let remaining=E.MAX_FILE_BYTES-start.length-end.length;const padding=' '.repeat(65536);while(remaining){let n=Math.min(remaining,padding.length);p.push(padding.slice(0,n));remaining-=n;}p.push(end);const big=p.finish();assert.equal(big.stats.charactersRead,E.MAX_FILE_BYTES);assert.equal(big.rows.length,1);assert(big.rows[0].evidence.some(e=>e.group==='sdk'));assert(big.stats.previewCharacters<1000);
console.log('PASS C parser: chunk boundaries, comments/literals, UTF-compatible text, nested braces, evidence beyond preview, ASM rejection, FAT address mapping, full 100 MiB streamed input.');

const budgetParser=D.create();for(let i=0;i<300;i++)budgetParser.push('void sub_'+(0x1000+i*16).toString(16)+'(){/*'+'x'.repeat(40000)+'*/sysctl(0); puts("integrity");}');const bounded=budgetParser.finish();assert.equal(bounded.rows.length,300);assert.equal(bounded.stats.previewCharacters,8*1024*1024);assert(bounded.rows.at(-1).bodyTruncated);assert(bounded.rows.at(-1).evidence.some(e=>e.group==='integrity'));assert(bounded.rows.every(r=>!('previewParts' in r)));console.log('PASS total preview budget with evidence after omitted content.');
