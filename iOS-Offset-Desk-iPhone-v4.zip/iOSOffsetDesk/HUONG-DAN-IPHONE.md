# iOS Offset Desk v4 — nhập 100 MiB và phân tích dấu hiệu

Bản này nâng giới hạn nhập cho **cả Mach-O và dump C UTF-8 lên 100 MiB (104.857.600 byte)**. Có bảng dấu hiệu bảo mật/anticheat với VA, RVA, file offset và bằng chứng. Không có chức năng tự xác nhận “offset anticheat” hoặc đánh giá hiệu quả tránh phát hiện. Bộ quét dùng quy tắc văn bản và tên API, không phải bộ suy luận hiểu đầy đủ mã máy.

## 1. Build và cập nhật app
1. Upload `iOS-Offset-Desk-iPhone-v4.zip` vào thư mục gốc repo GitHub `ipaoffset`. Giữ nguyên ZIP, không giải nén trước.
2. Lấy nội dung `build-ipa-v4.yml` kèm theo để thay file **`.github/workflows/build-ipa.yml`**. Đường dẫn workflow trong repo phải đúng như vậy, không có dấu chấm phía sau `.yml`.
3. Vào Actions → **Build iOS Offset Desk v4** → Run workflow. Workflow giải nén, chạy test parser, tạo project bằng XcodeGen, build ARM64 và đóng gói IPA chưa ký.
4. Khi thành công, tải artifact `iOS-Offset-Desk-v4-unsigned-IPA`, giải nén để lấy IPA. Ký và cài theo phương thức bạn đã dùng cho v3.
5. Mở app và kiểm tra tiêu đề **v4.0**. Nếu còn v3.0, bạn đang dùng bản cũ. Source ZIP không phải IPA cài trực tiếp.

## 2. Chọn đúng tệp
- **Mở Mach-O iOS:** chọn binary thực thi/thư viện đã lấy ra từ IPA. Không cần đổi tên hoặc thêm phần mở rộng. Không chọn trực tiếp IPA, ZIP, APK hoặc `.so` ELF Android.
- **Mở dump C / SO.C:** chọn văn bản UTF-8 có định nghĩa hàm `sub_HEX` hoặc `FUN_HEX` và dấu ngoặc thân hàm. Khai báo, lời gọi riêng lẻ hoặc hàm đã đổi tên không có địa chỉ không đủ để tự lập bảng VA.
- **File `.asm` do app xuất không phải C.** Đọc nó bằng trình xem văn bản/công cụ phân tích; nhập lại qua nút dump C sẽ bị báo sai định dạng.
- Nếu không chọn được file qua nhà cung cấp Tệp như 3uTools, sao chép vào **Tệp → Trên iPhone → iOS Offset Desk**, rồi chọn **Tệp trong ứng dụng → Mach-O/Dump C → tên file**. Đặt file trực tiếp trong thư mục, không đặt trong thư mục con.
- Dùng binary và dump C của cùng bản phát hành. Trùng địa chỉ không tự chứng minh cùng phiên bản. Nạp binary mới khi đã có binary trước đó sẽ bỏ dump C cũ để giảm nguy cơ trộn phiên bản.

## 3. Dump trên điện thoại
1. Nạp Mach-O; chờ thông báo thành công và danh sách section.
2. Trong **Dump mã ARM64 và dữ liệu**, chọn `__TEXT,__text` để đọc mã máy.
3. Thử **Bắt đầu trong section = `0x0`**, **Số byte = `0x100`** (256 byte), bấm **Dump ARM64 .asm** → Lưu vào Tệp.
4. Muốn xuất cả section, chọn lại section để lấy kích thước mặc định, giữ Bắt đầu = `0x0`.
5. Với `__cstring`, `__const`, `__data`, dùng HEX/BIN để xem dữ liệu. `__text` là mã, không tự đồng nghĩa anticheat; các section dữ liệu cũng không tự xác định vai trò bảo mật.
6. ASM/HEX giới hạn 64 MiB dữ liệu đầu vào mỗi lần xuất; BIN 100 MiB. Dung lượng văn bản xuất có thể lớn hơn nhiều so với byte đầu vào. Chia vùng nếu cần.

App đọc file tĩnh; không đọc bộ nhớ game khác, không giải mã FairPlay, không biến ASM thành mã giả C. Nếu cryptid khác 0, metadata vẫn có thể đọc nhưng ASM bị chặn vì vùng mã còn mã hóa.

## 4. Hiểu đúng địa chỉ
| Cột | Ý nghĩa |
|---|---|
| VA | Địa chỉ ảo trong Mach-O; với dump C đơn lẻ chỉ suy từ nhãn hàm |
| RVA (__TEXT) | VA trừ địa chỉ nền __TEXT |
| File offset | Vị trí byte tính từ đầu toàn bộ file; gồm phần dịch slice trong FAT binary |
| Slice offset | Vị trí tính từ đầu slice kiến trúc đã chọn |
| Địa chỉ chuỗi | Nơi chứa văn bản; không phải địa chỉ hàm dùng văn bản đó |

**Bắt đầu trong section** là độ lệch tính từ đầu section. Ví dụ minh họa: section bắt đầu VA `0x1000`, mục tiêu VA `0x1100` → nhập `0x100`. Đây là ví dụ số học, không phải offset của game. Chỉ áp dụng khi mục tiêu thuộc section đang chọn. Địa chỉ lúc chạy còn phụ thuộc ASLR.

## 5. Đọc bảng dấu hiệu anticheat
Bảng mục 5 được cập nhật sau khi nạp tệp; lọc theo **Hàm/symbol** hoặc **Chuỗi dữ liệu**. Chọn dòng để xem bằng chứng. Có thể xuất CSV/JSON toàn bộ dấu hiệu đang giữ, gồm địa chỉ và chú thích mức chắc chắn.

| Nhóm dấu hiệu | Ví dụ quy tắc | Cách diễn giải |
|---|---|---|
| Tên SDK/bảo mật | AnoSDK, AntiCheatExpert, anti-cheat, anti-tamper | Đầu mối về SDK/vai trò bảo mật; không chứng minh mọi hàm mang tên đó là kiểm tra gian lận |
| Tính toàn vẹn | integrity, checksum, tamper, code signature | Cần xác định dữ liệu được kiểm tra và cách dùng kết quả |
| Môi trường thiết bị | jailbreak, emulator detection | Có thể liên quan kiểm tra môi trường; cần đọc ngữ cảnh |
| Debugger | anti-debug, debugger attached | Chuỗi/tên chỉ là dấu hiệu, chưa đủ chứng minh hành vi |
| Báo cáo bảo mật | cheat report, security report | Chưa xác định nơi gửi, điều kiện gửi hay nội dung thực tế |
| API dùng chung | SHA, memcmp, sysctl, ptrace, liệt kê thư viện, đọc bộ nhớ | Bằng chứng yếu: nhiều chức năng bình thường cũng dùng các API này |

Không coi một giá trị `return -1`, `return 0`, tên `sub_...`, lời gọi mạng hoặc phép hash là bằng chứng đủ. Bộ quét bỏ comment khi xét dấu hiệu trong dump C, giữ nguyên nguồn chứng cứ và không gán chuỗi cho hàm gần nhất. Không có % “chắc chắn anticheat” hoặc danh sách “offset antiban” được tạo ra từ phỏng đoán.

## 6. Quy trình xác minh vai trò của một hàm
1. Ghi tên binary, bản phát hành, UUID và loại địa chỉ. Đối chiếu dump C với binary cùng bản.
2. Nếu dấu hiệu là chuỗi, tìm các tham chiếu đến chuỗi. App chưa phân tích XREF ARM64; chưa thể kết luận hàm nào sử dụng chuỗi chỉ từ bảng này.
3. Nếu dấu hiệu là hàm, đọc tham số, dữ liệu đầu vào, nhánh điều kiện, lời gọi và kết quả trả về. Bản xem trước có thể bị rút gọn, cần đối chiếu dump gốc.
4. Theo dõi nơi dùng kết quả: ghi log, xử lý lỗi, xác thực dữ liệu hay quyết định bảo mật? Giữ các giải thích thay thế, ví dụ kiểm tra checksum để xác minh tải file chứ không kiểm tra gian lận.
5. Chỉ mô tả vai trò có bằng chứng. Mẫu ghi chép: **giả thuyết → đoạn mã/chuỗi hỗ trợ → hàm gọi/được gọi → giải thích khác → điểm chưa xác minh**.
6. Không có kết quả không chứng minh không có anticheat: symbol có thể bị xóa, chuỗi mã hóa, hoặc logic nằm ở binary khác/phía máy chủ.

## 7. Làm tiếp trên Windows bằng Ghidra
1. Tải bản phát hành chính thức, cài Java theo hướng dẫn đi kèm đúng phiên bản và chạy `ghidraRun.bat`.
2. Tạo project local; import chính Mach-O đã phân tích; mở CodeBrowser và chạy phân tích tự động.
3. Đối chiếu địa chỉ nền/section. Dùng Go To với **VA** của mục tiêu. Không mặc định file offset là VA; nếu project đã rebase cần điều chỉnh theo địa chỉ nền mới.
4. Với chuỗi, xem References/XREF. Với hàm, xem Listing, Decompiler và các hàm gọi/được gọi.
5. Xác minh ý nghĩa theo quy trình mục 6. Mã decompiler là kết quả suy luận, không phải mã nguồn gốc; tên/kiểu có thể cần chỉnh sau phân tích.

Nguồn tham khảo chính thức:
- Ghidra và hướng dẫn cài: https://github.com/NationalSecurityAgency/ghidra
- Định dạng Mach-O: https://github.com/apple-oss-distributions/xnu/blob/main/EXTERNAL_HEADERS/mach-o/loader.h

## 8. Giới hạn kỹ thuật minh bạch
- Giới hạn nhập là 100 MiB mỗi tệp, không phải cam kết iOS luôn cấp đủ bộ nhớ. Mach-O vẫn cần một buffer đầu vào để đọc metadata; buffer được bỏ sau phân tích, model không giữ nó qua closure.
- Dump C đọc từng phần, không tạo chuỗi 100 MiB rồi nhân bản để mask comment. Giữ tối đa 100.000 hàm; vượt mức này báo lỗi và yêu cầu chia file.
- Bản xem trước: tối đa 32.768 ký tự/hàm, tổng 8.388.608 ký tự. Khi hết ngân sách, vẫn đọc tiếp và xét quy tắc dấu hiệu, nhưng không giữ toàn bộ thân hàm để hiển thị/xuất.
- Giữ tối đa 256 tên lời gọi/hàm và 24 bằng chứng đã khử trùng lặp/hàm. Chuỗi literal chỉ xét 4.096 ký tự đầu. Bộ đọc không phải trình biên dịch C/C++ đầy đủ.
- Quét binary chỉ xét chuỗi ASCII in được, kết thúc NUL, dài 5–4.096 byte; giữ tối đa 2.000 chuỗi trùng quy tắc. Không quét chuỗi UTF-16 hoặc giải mã chuỗi bị mã hóa. Nếu đạt giới hạn, giao diện ghi rõ.
- Metadata không bảo đảm liệt kê mọi hàm. Symbol có thể là nhãn. Giới hạn bảo vệ: 16.384 load command, 2.000.000 symbol và 100.000 mục hàm.
- CSV danh sách địa chỉ vẫn chứa các mục được parser giữ. JSON và phần đọc hàm chỉ có **bản xem trước** khi bị rút gọn, không thể dùng thay bản dump C gốc.
- Tên “image” đã đổi thành Tên file thực thi/thư viện lúc chạy, chỉ dùng khi sinh mã. Không cần điền để dump. ABI phải được xác minh; không điền số lượng tham số như `1` vào ô kiểu tham số.

## 9. Khi có lỗi
Dùng **Xuất nhật ký lỗi** và gửi cùng phiên bản app, dung lượng, loại file, thao tác gây lỗi. Lỗi 16 MiB nghĩa là vẫn đang chạy bản cũ. Nếu WebContent đóng, app báo chưa xác định nguyên nhân và yêu cầu nạp lại, không tự kết luận thiếu RAM. Phiên chưa được tự khôi phục.

## 10. Đã kiểm tra và chưa kiểm tra
Đã kiểm tra trên Linux/Node/JSDOM: nhập Mach-O 100 MiB, dump C 100 MiB theo từng phần, từ chối 100 MiB + 1 byte; các ranh giới chunk/UTF-8; phân trang, lọc, chọn dòng, trạng thái bận/reset; bằng chứng ngoài phần thân được giữ; bỏ comment; phân biệt ASM/C; địa chỉ chuỗi đối chiếu byte gốc; không đổi kết quả offset/CSV/khung mã của bộ kiểm tra cũ.

Tệp Mach-O thực tế đã đọc 12.832 mục địa chỉ. Tệp thử 100 MiB Mach-O là bản đệm thêm byte để kiểm tra dung lượng, không đại diện cho mọi binary phức tạp 100 MiB. Dump C thử 100 MiB chứa padding và hàm hợp lệ để kiểm tra đọc hết tệp, không đại diện cho mọi cấu trúc C/C++.

Chưa build bằng Xcode hoặc chạy UIKit/WebKit trên iPhone trong môi trường hiện tại. Workflow sẽ build thực tế trên macOS khi bạn chạy Actions. Chi tiết kiểm tra nằm trong `VALIDATION.json`; test parser trong `Tests/parser.test.cjs`.
